package com.jarvismini.llm

object LLMStub {
    fun reply(input: String): String = "Jarvis(stub): $input"
}
