package com.jarvismini

import android.app.Application

class CoreApp : Application()
