package com.jarvismini.automation

object SmartAutoReply {
    fun generateReply(msg: String): String {
        return "Hello! I am Jarvis. How can I help?"
    }
}
